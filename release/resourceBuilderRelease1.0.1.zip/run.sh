#!/bin/sh
VERSION=1.0.1
rm mcdiscPack-*.zip
java -jar mcdiscResourcePackBuilder-all-${VERSION} .
zip -r mcdiscPack-$(date +%d-%m-%Y).zip assets pack.mcmeta
